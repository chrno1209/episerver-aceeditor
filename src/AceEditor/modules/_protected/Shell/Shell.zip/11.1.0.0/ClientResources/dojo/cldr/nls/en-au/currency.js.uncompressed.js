define(
"dojo/cldr/nls/en-au/currency", //begin v1.x content
{
	"AUD_symbol": "$",
	"USD_symbol": "US$"
}
//end v1.x content
);